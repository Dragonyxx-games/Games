# Game Codes

A starter Next.js + Supabase app for a small game-code business.

## Included

- Google sign-in through Supabase Auth
- One scrollable customer page
- Multi-select stock games: Stompshot, Cabinet Row, Deepglow Brawl
- Multiple custom game requests submitted together
- Admin dashboard for `ama30@fessenden.org`
- Admin status controls: New / In Progress / Completed
- Display names in the interface; customer emails are not displayed
- Row-level database security: customers can read only their own requests; the admin can read all requests and update statuses

## Before publishing

This ZIP is application source code, not a live website. You need a Supabase project for login/database and a Vercel project for public hosting. Never put Google OAuth client secrets in this source code or send them in chat.

## Setup

1. Create a Supabase project.
2. In Supabase **SQL Editor**, run the included `supabase.sql`.
3. In Supabase **Authentication → Providers**, enable Google.
4. In Google Cloud Console, create a Google OAuth client. Add the Supabase callback URL shown in Supabase's Google provider setup as an authorized redirect URI.
5. In Supabase **Authentication → URL Configuration**, set the Site URL to your eventual public Vercel URL and add that URL as an allowed redirect URL. You can update these after deployment.
6. Copy `.env.example` to `.env.local` and set:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
7. Test locally with `npm install` and `npm run dev`, or deploy to Vercel and set the same two environment variables in the Vercel project settings.

## Publish with Vercel

1. Sign in to Vercel and open Vercel Drop: https://vercel.com/drop
2. Upload the project ZIP/folder if Drop is available to your account. If the Drop flow doesn't accept this project or ZIP, import the project from a Git repository instead.
3. In the Vercel project's **Settings → Environment Variables**, add the two public Supabase values from `.env.local` (do not include the `.env.local` file in a public repository).
4. Deploy. Copy the resulting `https://….vercel.app` URL.
5. Add that exact URL to Supabase Auth's allowed redirect URLs and set it as the Site URL.
6. Sign out and test Google login, a customer submission, and the admin dashboard.

## Admin and security

The admin account is checked against the authenticated email `ama30@fessenden.org`. Database row-level security (RLS) independently enforces that only this account can read all requests or update statuses. The UI displays a Google-provided name rather than the email address.

The `owner_id` column ties each request to the authenticated Supabase user. Do not remove the RLS policies or expose the Supabase service-role key in the browser. The anon/public key is intended for browser use when RLS is configured correctly.

If you previously ran the older starter SQL, rerun the updated `supabase.sql`. Any old rows without `owner_id` will remain hidden from ordinary users; new requests will be tied to their signed-in owner.
