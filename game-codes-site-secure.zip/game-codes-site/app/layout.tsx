import "./globals.css";
import type { ReactNode } from "react";

export const metadata = { title: "Game Codes", description: "Game code requests" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}