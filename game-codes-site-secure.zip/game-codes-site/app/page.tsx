 "use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase-browser";

const ADMIN_EMAIL = "ama30@fessenden.org";
const STOCK = ["Stompshot", "Cabinet Row", "Deepglow Brawl"];

type RequestRow = {
  id: string; customer_name: string; type: string; stock_games: string[];
  title: string | null; description: string | null; status: string;
  created_at: string;
};

export default function Home() {
  const supabase = supabaseBrowser();
  const [user, setUser] = useState<any>(null);
  const [stock, setStock] = useState<string[]>([]);
  const [customs, setCustoms] = useState([{title:"", description:""}]);
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [admin, setAdmin] = useState(false);
  const [view, setView] = useState<"home"|"admin">("home");
  const [message, setMessage] = useState("");

  useEffect(() => {
    supabase.auth.getUser().then(({data}) => {
      if (data.user) {
        setUser(data.user);
        setAdmin((data.user.email || "").toLowerCase() === ADMIN_EMAIL);
      }
    });
    const {data: sub} = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
      setAdmin((session?.user?.email || "").toLowerCase() === ADMIN_EMAIL);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  async function login() {
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: window.location.origin }
    });
  }

  async function logout() {
    await supabase.auth.signOut();
    setView("home");
  }

  function addCustom() {
    setCustoms([...customs, {title:"", description:""}]);
  }

  function updateCustom(i:number, key:"title"|"description", value:string) {
    setCustoms(customs.map((c,idx)=>idx===i ? {...c,[key]:value} : c));
  }

  async function submitAll() {
    setMessage("");
    const validCustoms = customs.filter(c => c.description.trim());
    if (!stock.length && !validCustoms.length) {
      setMessage("Select at least one stock game or add a custom request.");
      return;
    }
    const name = user.user_metadata?.full_name || user.user_metadata?.name || "Customer";
    const rows = [
      ...(stock.length ? [{owner_id:user.id,customer_name:name,type:"stock",stock_games:stock,title:null,description:null,status:"New"}] : []),
      ...validCustoms.map(c => ({owner_id:user.id,customer_name:name,type:"custom",stock_games:[],title:c.title.trim()||"Custom Game",description:c.description.trim(),status:"New"}))
    ];
    const {error} = await supabase.from("requests").insert(rows);
    if (error) { setMessage(error.message); return; }
    setStock([]); setCustoms([{title:"",description:""}]);
    setMessage("Submitted! Your requests are now in the system.");
  }

  async function loadRequests() {
    const {data,error} = await supabase.from("requests").select("*").order("created_at",{ascending:false});
    if (!error) setRequests(data || []);
    else setMessage(error.message);
  }

  async function updateStatus(id:string,status:string) {
    await supabase.from("requests").update({status}).eq("id",id);
    loadRequests();
  }

  if (!user) return (
    <main className="login">
      <div className="login-card">
        <div className="logo">🎮</div>
        <h1>Game Codes</h1>
        <p>Get one of our stock games or request a custom game.</p>
        <button className="google" onClick={login}><b>G</b> Continue with Google</button>
        <small>Secure sign-in powered by Google.</small>
      </div>
    </main>
  );

  return (
    <main>
      <header>
        <div className="brand">🎮 <b>Game Codes</b></div>
        <nav>
          <button onClick={()=>setView("home")}>Home</button>
          {admin && <button onClick={()=>{setView("admin");loadRequests()}}>Admin</button>}
          <span>{user.user_metadata?.full_name || user.user_metadata?.name || "Customer"}</span>
          <button onClick={logout}>Sign out</button>
        </nav>
      </header>

      {view === "admin" && admin ? (
        <section className="container">
          <div className="hero compact"><h1>Admin Dashboard</h1><p>Review and manage all submitted requests.</p></div>
          <div className="stats"><div><b>{requests.length}</b><span>Total</span></div><div><b>{requests.filter(r=>r.status==="New").length}</b><span>New</span></div><div><b>{requests.filter(r=>r.status==="In Progress").length}</b><span>In Progress</span></div><div><b>{requests.filter(r=>r.status==="Completed").length}</b><span>Completed</span></div></div>
          <div className="requests">
            {requests.map(r => <article className="request" key={r.id}>
              <div><h3>{r.customer_name}</h3><span className="pill">{r.type === "stock" ? r.stock_games.join(", ") : r.title}</span></div>
              {r.description && <p>{r.description}</p>}
              <div className="request-bottom"><time>{new Date(r.created_at).toLocaleString()}</time>
                <select value={r.status} onChange={e=>updateStatus(r.id,e.target.value)}>
                  <option>New</option><option>In Progress</option><option>Completed</option>
                </select>
              </div>
            </article>)}
            {!requests.length && <p className="empty">No requests yet.</p>}
          </div>
        </section>
      ) : (
        <section className="container">
          <div className="hero">
            <span>WELCOME TO GAME CODES</span><h1>Choose Your Games &<br/>Custom Requests</h1>
            <p>Select any stock games and/or add multiple custom game requests. Everything can be submitted together.</p>
          </div>

          <section className="panel">
            <div className="section-title"><div><h2>Stock Games</h2><p>Select one or more.</p></div><span className="count">{stock.length} selected</span></div>
            <div className="games">
              {STOCK.map(game => <button key={game} className={"game "+(stock.includes(game)?"selected":"")} onClick={()=>setStock(stock.includes(game)?stock.filter(x=>x!==game):[...stock,game])}>
                <div className="game-art">{game === "Stompshot" ? "💥" : game === "Cabinet Row" ? "🕹️" : "⚡"}</div><h3>{game}</h3><p>{game==="Stompshot"?"Fast-paced action.":game==="Cabinet Row"?"Arcade-style battles.":"High-energy combat."}</p><span>☐ Select</span>
              </button>)}
            </div>
          </section>

          <section className="panel">
            <div className="section-title"><div><h2>Custom Game Requests</h2><p>Submit as many different custom ideas as you want.</p></div><button className="add" onClick={addCustom}>＋ Add Another</button></div>
            {customs.map((c,i)=><div className="custom" key={i}><div className="number">{i+1}</div><div className="fields">
              <label>Request title (optional)<input value={c.title} onChange={e=>updateCustom(i,"title",e.target.value)} placeholder="e.g. Open World Survival"/></label>
              <label>Detailed request<textarea value={c.description} onChange={e=>updateCustom(i,"description",e.target.value)} placeholder="Describe the game, mechanics, style, features, and anything else you want..."/></label>
            </div>{customs.length>1 && <button className="remove" onClick={()=>setCustoms(customs.filter((_,idx)=>idx!==i))}>×</button>}</div>)}
          </section>

          <section className="submit-panel">
            <div><b>Ready to submit?</b><span>{stock.length} stock game{stock.length!==1?"s":""} · {customs.filter(c=>c.description.trim()).length} custom request{customs.filter(c=>c.description.trim()).length!==1?"s":""}</span></div>
            <button className="submit" onClick={submitAll}>Submit All Requests →</button>
          </section>
          {message && <div className="message">{message}</div>}
        </section>
      )}
    </main>
  );
}