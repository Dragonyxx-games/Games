-- Run this in the Supabase SQL Editor.
-- Safe for a fresh setup and also adds owner_id if you already created the starter table.
create extension if not exists "pgcrypto";

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  customer_name text not null,
  type text not null check (type in ('stock','custom')),
  stock_games text[] not null default '{}',
  title text,
  description text,
  status text not null default 'New' check (status in ('New','In Progress','Completed')),
  created_at timestamptz not null default now()
);

alter table public.requests
  add column if not exists owner_id uuid references auth.users(id) on delete cascade;

alter table public.requests enable row level security;

-- Remove the starter policies if this SQL is being rerun.
drop policy if exists "authenticated users can create requests" on public.requests;
drop policy if exists "authenticated users can read requests" on public.requests;
drop policy if exists "users can read own requests and admin can read all" on public.requests;
drop policy if exists "admin can update requests" on public.requests;

-- A customer can submit only for their own signed-in Google account.
create policy "authenticated users can create requests"
on public.requests for insert to authenticated
with check (owner_id = auth.uid());

-- Customers can read only their own requests. The admin can read all requests.
create policy "users can read own requests and admin can read all"
on public.requests for select to authenticated
using (
  owner_id = auth.uid()
  or lower(coalesce(auth.jwt() ->> 'email', '')) = 'ama30@fessenden.org'
);

-- Only the configured admin account can change request statuses.
create policy "admin can update requests"
on public.requests for update to authenticated
using (lower(coalesce(auth.jwt() ->> 'email', '')) = 'ama30@fessenden.org')
with check (lower(coalesce(auth.jwt() ->> 'email', '')) = 'ama30@fessenden.org');

-- Existing rows from the earlier starter version have owner_id = NULL and are
-- intentionally not visible to ordinary users. For a brand-new project, no action is needed.
